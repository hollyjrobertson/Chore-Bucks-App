class SessionsController < ApplicationController
  def new
  end
  def create
  end
  def welcome
  end
  def page_requires_login
  end
  def destroy
  end
end
